import SwiftUI
import UniformTypeIdentifiers

@main
struct SaxzyModVIPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

enum AppTheme: String, CaseIterable, Identifiable {
    case cyberCyan = "Cyber Cyan"
    case crimsonVIP = "Crimson VIP"
    case royalGold = "Royal Gold"
    case neonViolet = "Neon Violet"

    var id: String { rawValue }

    var primary: Color {
        switch self {
        case .cyberCyan:  return Color(red: 0.22, green: 0.88, blue: 1.00)
        case .crimsonVIP: return Color(red: 1.00, green: 0.22, blue: 0.36)
        case .royalGold:  return Color(red: 1.00, green: 0.80, blue: 0.25)
        case .neonViolet: return Color(red: 0.72, green: 0.36, blue: 1.00)
        }
    }

    var secondary: Color {
        switch self {
        case .cyberCyan:  return Color(red: 0.14, green: 0.44, blue: 1.00)
        case .crimsonVIP: return Color(red: 1.00, green: 0.45, blue: 0.16)
        case .royalGold:  return Color(red: 1.00, green: 0.52, blue: 0.10)
        case .neonViolet: return Color(red: 0.22, green: 0.76, blue: 1.00)
        }
    }

    var backgroundTop: Color {
        switch self {
        case .cyberCyan:  return Color(red: 0.03, green: 0.05, blue: 0.11)
        case .crimsonVIP: return Color(red: 0.09, green: 0.02, blue: 0.05)
        case .royalGold:  return Color(red: 0.08, green: 0.06, blue: 0.02)
        case .neonViolet: return Color(red: 0.06, green: 0.03, blue: 0.11)
        }
    }

    var backgroundBottom: Color {
        Color(red: 0.02, green: 0.02, blue: 0.04)
    }

    var gradient: LinearGradient {
        LinearGradient(
            colors: [primary, secondary],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
}

struct SharedFile: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

struct ContentView: View {
    @AppStorage("saxzy_unlocked") private var unlocked = false
    @AppStorage("saxzy_theme") private var selectedThemeRaw = AppTheme.cyberCyan.rawValue
    @AppStorage("saxzy_passcode") private var savedPassword = ""

    @State private var password = ""
    @State private var showPassword = false
    @State private var files: [URL] = []
    @State private var showingImporter = false
    @State private var showingThemeSheet = false
    @State private var selectedFile: SharedFile?
    @State private var inspectingFile: SharedFile?
    @State private var notice = "Welcome to Saxzy Mod VIP v3"
    @State private var searchText = ""

    private var theme: AppTheme {
        AppTheme(rawValue: selectedThemeRaw) ?? .cyberCyan
    }

    private var filteredFiles: [URL] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return files }
        return files.filter { $0.lastPathComponent.localizedCaseInsensitiveContains(query) }
    }

    private var storageDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let folder = docs.appendingPathComponent("SaxzyVault", isDirectory: true)
        if !FileManager.default.fileExists(atPath: folder.path) {
            try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        }
        return folder
    }

    var body: some View {
        ZStack {
            ambientBackground
            if unlocked {
                fileHome
            } else {
                loginView
            }
        }
        .preferredColorScheme(.dark)
        .tint(theme.primary)
        .onAppear {
            loadStoredFiles()
        }
        .fileImporter(
            isPresented: $showingImporter,
            allowedContentTypes: [.item],
            allowsMultipleSelection: true
        ) { result in
            handleImport(result)
        }
        .sheet(item: $selectedFile) { item in
            ShareSheet(url: item.url)
                .presentationDetents([.medium])
        }
        .fullScreenCover(item: $inspectingFile) { item in
            FileInspectorView(url: item.url, theme: theme) { message in
                notice = message
                loadStoredFiles()
            }
        }
        .sheet(isPresented: $showingThemeSheet) {
            themePickerSheet
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
        }
    }

    private var ambientBackground: some View {
        ZStack {
            LinearGradient(
                colors: [theme.backgroundTop, theme.backgroundBottom],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            Circle()
                .fill(theme.primary.opacity(0.22))
                .frame(width: 280, height: 280)
                .blur(radius: 90)
                .offset(x: -110, y: -260)

            Circle()
                .fill(theme.secondary.opacity(0.18))
                .frame(width: 260, height: 260)
                .blur(radius: 95)
                .offset(x: 130, y: 280)
        }
    }

    private var loginView: some View {
        VStack(spacing: 22) {
            HStack {
                Spacer()
                Button {
                    showingThemeSheet = true
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "paintpalette.fill")
                        Text(theme.rawValue)
                            .font(.caption.bold())
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.white.opacity(0.08))
                    .overlay(
                        Capsule().stroke(theme.primary.opacity(0.45), lineWidth: 1)
                    )
                    .clipShape(Capsule())
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 10)

            Spacer()

            ZStack {
                RoundedRectangle(cornerRadius: 30)
                    .fill(theme.gradient)
                    .frame(width: 196, height: 196)
                    .blur(radius: 26)
                    .opacity(0.45)

                Image("LaunchLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 185, height: 185)
                    .clipShape(RoundedRectangle(cornerRadius: 26))
                    .overlay(
                        RoundedRectangle(cornerRadius: 26)
                            .stroke(theme.gradient, lineWidth: 2)
                    )
                    .shadow(color: theme.primary.opacity(0.35), radius: 18, y: 8)
            }

            VStack(spacing: 6) {
                Text("SAXZY MOD VIP")
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.white, theme.primary],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                Text("PERSONAL EDITION · V3 INSPECTOR")
                    .font(.caption.bold())
                    .tracking(3.0)
                    .foregroundColor(theme.primary.opacity(0.9))
            }

            VStack(spacing: 14) {
                HStack(spacing: 10) {
                    Image(systemName: "lock.shield.fill")
                        .foregroundColor(theme.primary)

                    if showPassword {
                        TextField(savedPassword.isEmpty ? "Create a password (8+ chars)" : "Enter your password", text: $password)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .foregroundColor(.white)
                    } else {
                        SecureField(savedPassword.isEmpty ? "Create a password (8+ chars)" : "Enter your password", text: $password)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .foregroundColor(.white)
                    }

                    Button {
                        showPassword.toggle()
                    } label: {
                        Image(systemName: showPassword ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.white.opacity(0.6))
                    }
                }
                .padding(15)
                .background(Color.white.opacity(0.07))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(theme.primary.opacity(0.35), lineWidth: 1)
                )
                .clipShape(RoundedRectangle(cornerRadius: 14))

                Button(action: handleUnlock) {
                    HStack(spacing: 8) {
                        Image(systemName: "bolt.fill")
                        Text(savedPassword.isEmpty ? "SET PASSWORD & UNLOCK" : "UNLOCK")
                    }
                    .font(.headline.bold())
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(theme.gradient)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .shadow(color: theme.primary.opacity(0.4), radius: 14, y: 6)
                }

                Text(notice)
                    .font(.footnote)
                    .foregroundColor(theme.primary.opacity(0.9))
                    .multilineTextAlignment(.center)
            }
            .padding(20)
            .background(Color.white.opacity(0.05))
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .padding(.horizontal, 22)

            Spacer()

            Text("Local device lock · Files stay on your iPhone")
                .font(.caption2)
                .foregroundColor(.white.opacity(0.45))
                .padding(.bottom, 12)
        }
    }

    private var fileHome: some View {
        VStack(spacing: 14) {
            // Top VIP Header Bar
            HStack(spacing: 12) {
                Image("LaunchLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 48, height: 48)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(theme.gradient, lineWidth: 1.5)
                    )

                VStack(alignment: .leading, spacing: 2) {
                    Text("SAXZY MOD VIP")
                        .font(.headline.bold())
                        .foregroundColor(.white)
                    Text(theme.rawValue + " · Vault v3")
                        .font(.caption)
                        .foregroundColor(theme.primary)
                }

                Spacer()

                Button {
                    showingThemeSheet = true
                } label: {
                    Image(systemName: "paintpalette.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(theme.primary)
                        .frame(width: 38, height: 38)
                        .background(Color.white.opacity(0.08))
                        .clipShape(Circle())
                }

                Button {
                    unlocked = false
                    notice = "Vault locked"
                } label: {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 38, height: 38)
                        .background(Color.white.opacity(0.08))
                        .clipShape(Circle())
                }

                Button {
                    showingImporter = true
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                        .frame(width: 38, height: 38)
                        .background(theme.gradient)
                        .clipShape(Circle())
                        .shadow(color: theme.primary.opacity(0.45), radius: 8)
                }
            }
            .padding(14)
            .background(Color.white.opacity(0.06))
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(theme.primary.opacity(0.28), lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .padding(.horizontal, 16)
            .padding(.top, 8)

            // Search Bar
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(theme.primary.opacity(0.8))
                TextField("Search files...", text: $searchText)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .foregroundColor(.white)
                if !searchText.isEmpty {
                    Button {
                        searchText = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.white.opacity(0.5))
                    }
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 11)
            .background(Color.white.opacity(0.06))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .padding(.horizontal, 16)

            // Section Title
            HStack {
                Text("MY FILES · TAP TO VIEW")
                    .font(.caption.bold())
                    .tracking(1.6)
                    .foregroundColor(theme.primary)
                Spacer()
                Text("\(filteredFiles.count) items")
                    .font(.caption.bold())
                    .foregroundColor(.white.opacity(0.65))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.white.opacity(0.07))
                    .clipShape(Capsule())
            }
            .padding(.horizontal, 18)

            // File List or Empty State
            if filteredFiles.isEmpty {
                Spacer()
                VStack(spacing: 14) {
                    Image(systemName: "folder.badge.plus")
                        .font(.system(size: 46))
                        .foregroundStyle(theme.gradient)
                    Text(files.isEmpty ? "No files yet" : "No matching files")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text(files.isEmpty ? "Tap + to import configs, scripts, or documents. Tap any file to preview, edit text, or inspect Hex." : "Try a different search keyword.")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.6))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 36)
                    if files.isEmpty {
                        Button {
                            showingImporter = true
                        } label: {
                            Text("Import Files")
                                .font(.subheadline.bold())
                                .foregroundColor(.black)
                                .padding(.horizontal, 22)
                                .padding(.vertical, 11)
                                .background(theme.gradient)
                                .clipShape(Capsule())
                        }
                        .padding(.top, 4)
                    }
                }
                Spacer()
            } else {
                List {
                    ForEach(filteredFiles, id: \.self) { url in
                        HStack(spacing: 12) {
                            Button {
                                inspectingFile = SharedFile(url: url)
                            } label: {
                                HStack(spacing: 12) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(theme.primary.opacity(0.16))
                                            .frame(width: 44, height: 44)
                                        Image(systemName: iconName(for: url))
                                            .font(.system(size: 18, weight: .semibold))
                                            .foregroundColor(theme.primary)
                                    }

                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(url.lastPathComponent)
                                            .font(.subheadline.weight(.semibold))
                                            .foregroundColor(.white)
                                            .lineLimit(1)
                                        HStack(spacing: 8) {
                                            Text(url.pathExtension.isEmpty ? "FILE" : url.pathExtension.uppercased())
                                                .font(.caption2.bold())
                                                .foregroundColor(theme.primary)
                                                .padding(.horizontal, 6)
                                                .padding(.vertical, 2)
                                                .background(theme.primary.opacity(0.14))
                                                .clipShape(Capsule())
                                            Text(formattedFileSize(for: url))
                                                .font(.caption2)
                                                .foregroundColor(.white.opacity(0.55))
                                        }
                                    }
                                    Spacer()
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)

                            Button {
                                inspectingFile = SharedFile(url: url)
                            } label: {
                                Image(systemName: "eye.fill")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(.white)
                                    .frame(width: 34, height: 34)
                                    .background(Color.white.opacity(0.08))
                                    .clipShape(Circle())
                            }
                            .buttonStyle(.plain)

                            Button {
                                selectedFile = SharedFile(url: url)
                            } label: {
                                Image(systemName: "square.and.arrow.up")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(theme.primary)
                                    .frame(width: 34, height: 34)
                                    .background(Color.white.opacity(0.08))
                                    .clipShape(Circle())
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.vertical, 6)
                        .listRowBackground(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(Color.white.opacity(0.05))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(Color.white.opacity(0.08), lineWidth: 1)
                                )
                                .padding(.vertical, 4)
                        )
                        .listRowSeparator(.hidden)
                    }
                    .onDelete(perform: deleteFiles)
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .padding(.horizontal, 8)
            }

            // Status Bar
            HStack(spacing: 8) {
                Circle()
                    .fill(theme.primary)
                    .frame(width: 7, height: 7)
                Text(notice)
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.8))
                    .lineLimit(1)
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(Color.white.opacity(0.05))
            .clipShape(Capsule())
            .padding(.horizontal, 16)
            .padding(.bottom, 8)
        }
    }

    private var themePickerSheet: some View {
        ZStack {
            theme.backgroundBottom.ignoresSafeArea()
            VStack(spacing: 16) {
                Text("SELECT UI THEME")
                    .font(.headline.bold())
                    .tracking(2)
                    .foregroundColor(.white)
                    .padding(.top, 18)

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                    ForEach(AppTheme.allCases) { option in
                        let isSelected = option == theme
                        Button {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                selectedThemeRaw = option.rawValue
                                notice = "Theme set to \(option.rawValue)"
                            }
                        } label: {
                            VStack(spacing: 10) {
                                Circle()
                                    .fill(option.gradient)
                                    .frame(width: 46, height: 46)
                                    .overlay(
                                        Image(systemName: isSelected ? "checkmark" : "sparkles")
                                            .font(.headline.bold())
                                            .foregroundColor(.black)
                                    )
                                    .shadow(color: option.primary.opacity(0.5), radius: 10)

                                Text(option.rawValue)
                                    .font(.subheadline.bold())
                                    .foregroundColor(.white)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 18)
                            .background(Color.white.opacity(isSelected ? 0.12 : 0.05))
                            .overlay(
                                RoundedRectangle(cornerRadius: 18)
                                    .stroke(isSelected ? option.primary : Color.white.opacity(0.1), lineWidth: isSelected ? 2 : 1)
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 18))
                        }
                    }
                }
                .padding(.horizontal, 20)

                Spacer()
            }
        }
    }

    private func handleUnlock() {
        if savedPassword.isEmpty {
            guard password.count >= 8 else {
                notice = "Use at least 8 characters"
                return
            }
            savedPassword = password
            unlocked = true
            password = ""
            notice = "Password saved · Vault unlocked"
        } else {
            guard password == savedPassword else {
                notice = "Incorrect password"
                return
            }
            unlocked = true
            password = ""
            notice = "Welcome back to Saxzy Mod VIP"
        }
    }

    private func loadStoredFiles() {
        let contents = (try? FileManager.default.contentsOfDirectory(
            at: storageDirectory,
            includingPropertiesForKeys: [.creationDateKey],
            options: [.skipsHiddenFiles]
        )) ?? []
        files = contents.sorted { $0.lastPathComponent.lowercased() < $1.lastPathComponent.lowercased() }
    }

    private func handleImport(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            var importedCount = 0
            for url in urls {
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                let destination = storageDirectory.appendingPathComponent(url.lastPathComponent)
                do {
                    if FileManager.default.fileExists(atPath: destination.path) {
                        try FileManager.default.removeItem(at: destination)
                    }
                    try FileManager.default.copyItem(at: url, to: destination)
                    importedCount += 1
                } catch {
                    notice = "Could not import \(url.lastPathComponent)"
                }
            }
            loadStoredFiles()
            if importedCount > 0 {
                notice = "Imported \(importedCount) file(s)"
            }
        case .failure(let error):
            notice = error.localizedDescription
        }
    }

    private func deleteFiles(at offsets: IndexSet) {
        let targets = offsets.map { filteredFiles[$0] }
        for url in targets {
            try? FileManager.default.removeItem(at: url)
        }
        loadStoredFiles()
        notice = "Removed \(targets.count) file(s)"
    }

    private func iconName(for url: URL) -> String {
        switch url.pathExtension.lowercased() {
        case "zip", "rar", "7z", "ipa": return "archivebox.fill"
        case "json", "plist", "xml", "cfg", "ini": return "slider.horizontal.3"
        case "swift", "lua", "py", "js", "txt": return "doc.text.fill"
        case "png", "jpg", "jpeg", "heic": return "photo.fill"
        default: return "doc.fill"
        }
    }

    private func formattedFileSize(for url: URL) -> String {
        let values = try? url.resourceValues(forKeys: [.fileSizeKey])
        guard let bytes = values?.fileSize else { return "—" }
        return ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
