import SwiftUI
import QuickLook
import UIKit

enum InspectorTab: String, CaseIterable, Identifiable {
    case preview = "Preview"
    case text = "Text / Config"
    case hex = "Hex Viewer"

    var id: String { rawValue }
}

struct FileInspectorView: View {
    let url: URL
    let theme: AppTheme
    let onSaved: (String) -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var selectedTab: InspectorTab = .preview
    @State private var textContent = ""
    @State private var textError: String?
    @State private var isDirty = false
    @State private var showFindReplace = false
    @State private var findQuery = ""
    @State private var replaceQuery = ""
    @State private var statusMessage = ""
    @State private var showingShare = false

    // Hex Viewer state (paginated for large binary safety)
    private let pageSize = 2048 // 2 KB per page (128 rows of 16 bytes)
    @State private var fileSizeBytes: Int64 = 0
    @State private var currentPage: Int = 0
    @State private var hexRows: [HexRow] = []
    @State private var hexError: String?
    @State private var jumpOffsetText = ""

    private let maxEditableTextBytes: Int64 = 2 * 1024 * 1024 // 2 MB cap

    private var totalPages: Int {
        guard fileSizeBytes > 0 else { return 1 }
        return max(1, Int((fileSizeBytes + Int64(pageSize) - 1) / Int64(pageSize)))
    }

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [theme.backgroundTop, theme.backgroundBottom],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 12) {
                headerBar
                tabPicker

                Group {
                    switch selectedTab {
                    case .preview:
                        quickLookTab
                    case .text:
                        textEditorTab
                    case .hex:
                        hexViewerTab
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                if !statusMessage.isEmpty {
                    HStack(spacing: 8) {
                        Circle().fill(theme.primary).frame(width: 7, height: 7)
                        Text(statusMessage)
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.85))
                            .lineLimit(1)
                        Spacer()
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(Color.white.opacity(0.06))
                    .clipShape(Capsule())
                    .padding(.horizontal, 16)
                    .padding(.bottom, 6)
                }
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            detectFileMetadata()
            chooseDefaultTab()
            loadTextIfApplicable()
            loadHexPage(0)
        }
        .sheet(isPresented: $showingShare) {
            ShareSheet(url: url)
                .presentationDetents([.medium])
        }
    }

    private var headerBar: some View {
        HStack(spacing: 10) {
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 34, height: 34)
                    .background(Color.white.opacity(0.10))
                    .clipShape(Circle())
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(url.lastPathComponent)
                    .font(.subheadline.bold())
                    .foregroundColor(.white)
                    .lineLimit(1)
                Text("\(url.pathExtension.isEmpty ? "FILE" : url.pathExtension.uppercased()) · \(ByteCountFormatter.string(fromByteCount: fileSizeBytes, countStyle: .file))")
                    .font(.caption2)
                    .foregroundColor(theme.primary)
            }

            Spacer()

            Button {
                showingShare = true
            } label: {
                Image(systemName: "square.and.arrow.up")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(theme.primary)
                    .frame(width: 34, height: 34)
                    .background(Color.white.opacity(0.10))
                    .clipShape(Circle())
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 14)
    }

    private var tabPicker: some View {
        Picker("Mode", selection: $selectedTab) {
            ForEach(InspectorTab.allCases) { tab in
                Text(tab.rawValue).tag(tab)
            }
        }
        .pickerStyle(.segmented)
        .padding(.horizontal, 16)
    }

    // MARK: - Tab 1: QuickLook Preview
    private var quickLookTab: some View {
        VStack(spacing: 8) {
            QuickLookPreview(url: url)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(theme.primary.opacity(0.25), lineWidth: 1)
                )
                .padding(.horizontal, 16)
                .padding(.bottom, 12)
        }
    }

    // MARK: - Tab 2: Text / Config Editor
    private var textEditorTab: some View {
        VStack(spacing: 10) {
            if let error = textError {
                Spacer()
                VStack(spacing: 12) {
                    Image(systemName: "doc.text.magnifyingglass")
                        .font(.system(size: 40))
                        .foregroundStyle(theme.gradient)
                    Text("Cannot open as text")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.65))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 28)
                    Button {
                        selectedTab = .hex
                    } label: {
                        Text("Open in Hex Viewer")
                            .font(.subheadline.bold())
                            .foregroundColor(.black)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(theme.gradient)
                            .clipShape(Capsule())
                    }
                }
                Spacer()
            } else {
                // Toolbar for Text Editor
                HStack(spacing: 8) {
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            showFindReplace.toggle()
                        }
                    } label: {
                        Label("Find", systemImage: "magnifyingglass")
                            .font(.caption.bold())
                            .foregroundColor(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(showFindReplace ? theme.primary.opacity(0.3) : Color.white.opacity(0.08))
                            .clipShape(Capsule())
                    }

                    Text("\(textContent.components(separatedBy: .newlines).count) lines")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.6))

                    Spacer()

                    Button {
                        saveTextFile()
                    } label: {
                        Label("Save", systemImage: "checkmark.circle.fill")
                            .font(.caption.bold())
                            .foregroundColor(.black)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 7)
                            .background(isDirty ? theme.gradient : LinearGradient(colors: [Color.gray.opacity(0.5), Color.gray.opacity(0.5)], startPoint: .leading, endPoint: .trailing))
                            .clipShape(Capsule())
                    }
                    .disabled(!isDirty)
                }
                .padding(.horizontal, 16)

                if showFindReplace {
                    VStack(spacing: 8) {
                        HStack(spacing: 8) {
                            TextField("Find text...", text: $findQuery)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .font(.caption)
                                .padding(8)
                                .background(Color.white.opacity(0.08))
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                            TextField("Replace with...", text: $replaceQuery)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .font(.caption)
                                .padding(8)
                                .background(Color.white.opacity(0.08))
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                            Button("Replace All") {
                                replaceAllText()
                            }
                            .font(.caption.bold())
                            .foregroundColor(.black)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 8)
                            .background(theme.gradient)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .disabled(findQuery.isEmpty)
                        }
                    }
                    .padding(.horizontal, 16)
                }

                TextEditor(text: $textContent)
                    .font(.system(size: 13, design: .monospaced))
                    .foregroundColor(.white)
                    .scrollContentBackground(.hidden)
                    .padding(10)
                    .background(Color.white.opacity(0.05))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(theme.primary.opacity(0.30), lineWidth: 1)
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .padding(.horizontal, 16)
                    .padding(.bottom, 8)
                    .onChange(of: textContent) { _ in
                        isDirty = true
                    }
            }
        }
    }

    // MARK: - Tab 3: Hex Viewer
    private var hexViewerTab: some View {
        VStack(spacing: 10) {
            // Controls: Jump to offset + Copy page
            HStack(spacing: 8) {
                TextField("Offset hex (e.g. 1A00)", text: $jumpOffsetText)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .font(.system(size: 12, design: .monospaced))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(Color.white.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 8))

                Button("Go") {
                    jumpToHexOffset()
                }
                .font(.caption.bold())
                .foregroundColor(.black)
                .padding(.horizontal, 12)
                .padding(.vertical, 7)
                .background(theme.gradient)
                .clipShape(RoundedRectangle(cornerRadius: 8))

                Button {
                    copyCurrentHexPage()
                } label: {
                    Image(systemName: "doc.on.doc")
                        .font(.caption.bold())
                        .foregroundColor(theme.primary)
                        .padding(8)
                        .background(Color.white.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
            }
            .padding(.horizontal, 16)

            if let error = hexError {
                Spacer()
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red.opacity(0.9))
                    .padding()
                Spacer()
            } else {
                // Column Header
                HStack(spacing: 8) {
                    Text("OFFSET")
                        .frame(width: 66, alignment: .leading)
                    Text("00 01 02 03 04 05 06 07")
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text("ASCII")
                        .frame(width: 64, alignment: .leading)
                }
                .font(.system(size: 10, weight: .bold, design: .monospaced))
                .foregroundColor(theme.primary)
                .padding(.horizontal, 20)

                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 4) {
                        ForEach(hexRows) { row in
                            HStack(spacing: 8) {
                                Text(row.offsetHex)
                                    .foregroundColor(theme.primary.opacity(0.85))
                                    .frame(width: 66, alignment: .leading)
                                Text(row.bytesHex)
                                    .foregroundColor(.white.opacity(0.92))
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                Text(row.ascii)
                                    .foregroundColor(.white.opacity(0.6))
                                    .frame(width: 64, alignment: .leading)
                            }
                            .font(.system(size: 11, design: .monospaced))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 3)
                            .background(row.index % 2 == 0 ? Color.white.opacity(0.03) : Color.clear)
                        }
                    }
                    .padding(.vertical, 6)
                }
                .background(Color.white.opacity(0.04))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(theme.primary.opacity(0.25), lineWidth: 1)
                )
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .padding(.horizontal, 16)

                // Pagination Footer
                HStack {
                    Button {
                        if currentPage > 0 { loadHexPage(currentPage - 1) }
                    } label: {
                        Label("Prev", systemImage: "chevron.left")
                            .font(.caption.bold())
                            .foregroundColor(currentPage > 0 ? .white : .gray)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(Color.white.opacity(0.08))
                            .clipShape(Capsule())
                    }
                    .disabled(currentPage == 0)

                    Spacer()

                    Text("Page \(currentPage + 1) / \(totalPages)")
                        .font(.caption.bold())
                        .foregroundColor(.white.opacity(0.8))

                    Spacer()

                    Button {
                        if currentPage + 1 < totalPages { loadHexPage(currentPage + 1) }
                    } label: {
                        Label("Next", systemImage: "chevron.right")
                            .font(.caption.bold())
                            .foregroundColor(currentPage + 1 < totalPages ? .white : .gray)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(Color.white.opacity(0.08))
                            .clipShape(Capsule())
                    }
                    .disabled(currentPage + 1 >= totalPages)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 8)
            }
        }
    }

    // MARK: - Helpers
    private func detectFileMetadata() {
        let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
        fileSizeBytes = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
    }

    private func chooseDefaultTab() {
        let ext = url.pathExtension.lowercased()
        let textExts: Set<String> = ["txt", "json", "cfg", "ini", "xml", "plist", "lua", "swift", "py", "js", "yml", "yaml", "md", "log", "csv", "html", "css"]
        let binaryExts: Set<String> = ["bin", "dat", "so", "dylib", "ipa", "3105", "pak", "obb"]
        if textExts.contains(ext) {
            selectedTab = .text
        } else if binaryExts.contains(ext) {
            selectedTab = .hex
        } else {
            selectedTab = .preview
        }
    }

    private func loadTextIfApplicable() {
        if fileSizeBytes > maxEditableTextBytes {
            textError = "File is larger than 2 MB. Use Hex Viewer to inspect large files safely."
            return
        }
        do {
            let data = try Data(contentsOf: url)
            if let decoded = String(data: data, encoding: .utf8) {
                textContent = decoded
                textError = nil
                isDirty = false
            } else {
                textError = "This file contains binary data (not UTF-8 text). Switch to Hex Viewer or QuickLook Preview."
            }
        } catch {
            textError = "Failed to read file: \(error.localizedDescription)"
        }
    }

    private func saveTextFile() {
        guard let data = textContent.data(using: .utf8) else {
            statusMessage = "Could not encode UTF-8 text"
            return
        }
        do {
            try data.write(to: url, options: .atomic)
            detectFileMetadata()
            loadHexPage(currentPage)
            isDirty = false
            statusMessage = "Saved \(url.lastPathComponent)"
            onSaved("Saved \(url.lastPathComponent)")
        } catch {
            statusMessage = "Save failed: \(error.localizedDescription)"
        }
    }

    private func replaceAllText() {
        guard !findQuery.isEmpty else { return }
        let occurrences = textContent.components(separatedBy: findQuery).count - 1
        guard occurrences > 0 else {
            statusMessage = "No matches for '\(findQuery)'"
            return
        }
        textContent = textContent.replacingOccurrences(of: findQuery, with: replaceQuery)
        isDirty = true
        statusMessage = "Replaced \(occurrences) occurrence(s) · Tap Save"
    }

    private func loadHexPage(_ page: Int) {
        let clampedPage = max(0, min(page, totalPages - 1))
        let startOffset = UInt64(clampedPage) * UInt64(pageSize)
        do {
            let handle = try FileHandle(forReadingFrom: url)
            defer { try? handle.close() }
            try handle.seek(toOffset: startOffset)
            let chunk = handle.readData(ofLength: pageSize)
            let bytes = [UInt8](chunk)
            var rows: [HexRow] = []
            let strideSize = 8 // 8 bytes per row fits cleanly on iPhone SE width
            var idx = 0
            while idx < bytes.count {
                let end = min(idx + strideSize, bytes.count)
                let slice = bytes[idx..<end]
                let rowOffset = startOffset + UInt64(idx)
                let offsetHex = String(format: "%08llX", rowOffset)
                let hexPart = slice.map { String(format: "%02X", $0) }.joined(separator: " ")
                let asciiPart = slice.map { b -> String in
                    (b >= 32 && b <= 126) ? String(UnicodeScalar(b)) : "."
                }.joined()
                rows.append(HexRow(index: rows.count, offsetHex: offsetHex, bytesHex: hexPart, ascii: asciiPart))
                idx += strideSize
            }
            hexRows = rows
            currentPage = clampedPage
            hexError = nil
        } catch {
            hexError = "Could not read bytes: \(error.localizedDescription)"
        }
    }

    private func jumpToHexOffset() {
        let cleaned = jumpOffsetText
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "0x", with: "", options: .caseInsensitive)
        guard let target = Int64(cleaned, radix: 16), target >= 0 else {
            statusMessage = "Invalid hex offset"
            return
        }
        let clamped = min(target, max(0, fileSizeBytes - 1))
        let targetPage = Int(clamped / Int64(pageSize))
        loadHexPage(targetPage)
        statusMessage = String(format: "Jumped to 0x%llX (Page %d)", clamped, targetPage + 1)
    }

    private func copyCurrentHexPage() {
        let dump = hexRows.map { "\($0.offsetHex)  \($0.bytesHex)  \($0.ascii)" }.joined(separator: "\n")
        UIPasteboard.general.string = dump
        statusMessage = "Copied Hex page \(currentPage + 1) to clipboard"
    }
}

struct HexRow: Identifiable {
    let index: Int
    let offsetHex: String
    let bytesHex: String
    let ascii: String
    var id: Int { index }
}

struct QuickLookPreview: UIViewControllerRepresentable {
    let url: URL

    func makeCoordinator() -> Coordinator {
        Coordinator(url: url)
    }

    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: QLPreviewController, context: Context) {
        context.coordinator.url = url
        controller.reloadData()
    }

    class Coordinator: NSObject, QLPreviewControllerDataSource {
        var url: URL
        init(url: URL) { self.url = url }

        func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
            1
        }

        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            url as NSURL
        }
    }
}
