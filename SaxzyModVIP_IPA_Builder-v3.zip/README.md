# Saxzy Mod VIP v3 — File Inspector Edition

Includes 4 Neon UI themes, persistent Vault storage, QuickLook Preview, Text/Config Editor (with Find & Replace + Save), and paginated Hex Viewer with offset jump.
