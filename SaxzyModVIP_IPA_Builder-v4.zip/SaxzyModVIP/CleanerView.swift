import SwiftUI
import UIKit

struct CleanerView: View {
    let theme: AppTheme
    let storageDirectory: URL
    let onCleaned: (String) -> Void

    @State private var isScanning = false
    @State private var scanProgress: Double = 0.0
    @State private var scanStatus = "Ready to scan device & app cache"
    @State private var lastScanDate = "Not scanned yet"
    @State private var cacheBytes: Int64 = 0
    @State private var freeSpaceBytes: Int64 = 0
    @State private var totalSpaceBytes: Int64 = 0
    @State private var batteryPercent: Int = 0
    @State private var iosVersion: String = UIDevice.current.systemVersion
    @State private var deviceModel: String = UIDevice.current.model

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("CLEANER & SECURITY")
                            .font(.headline.bold())
                            .foregroundColor(.white)
                        Text("Device Diagnostics · App Cache")
                            .font(.caption)
                            .foregroundColor(theme.primary)
                    }
                    Spacer()
                    Image(systemName: "shield.lefthalf.filled")
                        .font(.system(size: 24))
                        .foregroundStyle(theme.gradient)
                }
                .padding(16)
                .background(Color.white.opacity(0.06))
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(theme.primary.opacity(0.28), lineWidth: 1)
                )
                .clipShape(RoundedRectangle(cornerRadius: 20))

                // Scan Ring Card
                VStack(spacing: 16) {
                    ZStack {
                        Circle()
                            .stroke(Color.white.opacity(0.10), lineWidth: 12)
                            .frame(width: 140, height: 140)

                        Circle()
                            .trim(from: 0, to: isScanning ? scanProgress : 1.0)
                            .stroke(theme.gradient, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                            .frame(width: 140, height: 140)
                            .rotationEffect(.degrees(-90))
                            .animation(.easeInOut(duration: 0.35), value: scanProgress)

                        VStack(spacing: 4) {
                            Image(systemName: isScanning ? "waveform.path.ecg" : "checkmark.shield.fill")
                                .font(.system(size: 32))
                                .foregroundStyle(theme.gradient)
                            Text(isScanning ? "\(Int(scanProgress * 100))%" : "SAFE")
                                .font(.headline.bold())
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.top, 8)

                    Text(scanStatus)
                        .font(.subheadline.weight(.medium))
                        .foregroundColor(.white.opacity(0.9))
                        .multilineTextAlignment(.center)

                    Text("Last check: \(lastScanDate)")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.55))

                    Button(action: runScanAndClean) {
                        HStack(spacing: 8) {
                            Image(systemName: isScanning ? "hourglass" : "sparkles")
                            Text(isScanning ? "SCANNING..." : "SCAN & CLEAN CACHE")
                        }
                        .font(.subheadline.bold())
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(theme.gradient)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .shadow(color: theme.primary.opacity(0.35), radius: 12, y: 4)
                    }
                    .disabled(isScanning)
                }
                .padding(20)
                .background(Color.white.opacity(0.05))
                .overlay(
                    RoundedRectangle(cornerRadius: 22)
                        .stroke(Color.white.opacity(0.10), lineWidth: 1)
                )
                .clipShape(RoundedRectangle(cornerRadius: 22))

                // Device Info Grid
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    statCard(
                        icon: "internaldrive.fill",
                        title: "Free Storage",
                        value: ByteCountFormatter.string(fromByteCount: freeSpaceBytes, countStyle: .file),
                        subtitle: "of \(ByteCountFormatter.string(fromByteCount: totalSpaceBytes, countStyle: .file))"
                    )
                    statCard(
                        icon: "trash.fill",
                        title: "App Temp/Cache",
                        value: ByteCountFormatter.string(fromByteCount: cacheBytes, countStyle: .file),
                        subtitle: "Safe to clear"
                    )
                    statCard(
                        icon: "battery.100",
                        title: "Battery",
                        value: batteryPercent >= 0 ? "\(batteryPercent)%" : "N/A",
                        subtitle: deviceModel
                    )
                    statCard(
                        icon: "iphone",
                        title: "System",
                        value: "iOS \(iosVersion)",
                        subtitle: "Sandbox Active"
                    )
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .onAppear {
            refreshStats()
        }
    }

    private func statCard(icon: String, title: String, value: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(theme.primary)
                Spacer()
            }
            Text(title)
                .font(.caption)
                .foregroundColor(.white.opacity(0.65))
            Text(value)
                .font(.headline.bold())
                .foregroundColor(.white)
                .lineLimit(1)
            Text(subtitle)
                .font(.caption2)
                .foregroundColor(theme.primary.opacity(0.85))
                .lineLimit(1)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.05))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func refreshStats() {
        UIDevice.current.isBatteryMonitoringEnabled = true
        let level = UIDevice.current.batteryLevel
        batteryPercent = level >= 0 ? Int(level * 100) : -1

        if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()) {
            freeSpaceBytes = (attrs[.systemFreeSize] as? NSNumber)?.int64Value ?? 0
            totalSpaceBytes = (attrs[.systemSize] as? NSNumber)?.int64Value ?? 0
        }
        cacheBytes = calculateTempAndCacheSize()
    }

    private func calculateTempAndCacheSize() -> Int64 {
        var total: Int64 = 0
        let fm = FileManager.default
        let tempDir = fm.temporaryDirectory
        let cacheDirs = fm.urls(for: .cachesDirectory, in: .userDomainMask)
        let dirs = [tempDir] + cacheDirs
        for dir in dirs {
            if let enumerator = fm.enumerator(at: dir, includingPropertiesForKeys: [.fileSizeKey]) {
                for case let fileURL as URL in enumerator {
                    if let size = try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize {
                        total += Int64(size)
                    }
                }
            }
        }
        return total
    }

    private func runScanAndClean() {
        isScanning = true
        scanProgress = 0.15
        scanStatus = "Checking app cache & temporary files..."

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            scanProgress = 0.60
            scanStatus = "Clearing temporary data..."
            let cleared = clearTempAndCache()

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                scanProgress = 1.0
                isScanning = false
                refreshStats()
                let formatter = DateFormatter()
                formatter.timeStyle = .short
                lastScanDate = formatter.string(from: Date())
                let clearedStr = ByteCountFormatter.string(fromByteCount: cleared, countStyle: .file)
                scanStatus = "Clean complete · Freed \(clearedStr)"
                onCleaned("Cleaned \(clearedStr) of app cache")
            }
        }
    }

    private func clearTempAndCache() -> Int64 {
        let before = calculateTempAndCacheSize()
        let fm = FileManager.default
        let tempDir = fm.temporaryDirectory
        if let items = try? fm.contentsOfDirectory(at: tempDir, includingPropertiesForKeys: nil) {
            for item in items {
                try? fm.removeItem(at: item)
            }
        }
        if let cacheDir = fm.urls(for: .cachesDirectory, in: .userDomainMask).first,
           let items = try? fm.contentsOfDirectory(at: cacheDir, includingPropertiesForKeys: nil) {
            for item in items {
                try? fm.removeItem(at: item)
            }
        }
        let after = calculateTempAndCacheSize()
        return max(0, before - after)
    }
}
