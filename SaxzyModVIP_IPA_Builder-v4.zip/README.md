# Saxzy Mod VIP v4

- Tab 1: Files Vault with native .3105 support (UTImportedTypeDeclarations + Share/Open In) and tap-to-inspect (QuickLook, Text Editor, Hex Viewer)
- Tab 2: Cleaner & Security (real device storage/battery/iOS diagnostics + app cache cleaner)
- Tab 3: Settings (4 Neon UI Themes, password update, lock vault)
